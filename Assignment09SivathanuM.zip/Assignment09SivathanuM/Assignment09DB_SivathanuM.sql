--*************************************************************************--
-- Title: Assignment09
-- Author: SivathanuM
-- Desc: Sql code to create course enrollment for students
-- Change Log: When,Who,What
-- 2021-03-15,SivathanuM,Created Database and tables
-- 2021-03-16, SivathanuM,Created Views
-- 2021-03-17 , SivathanuM , Created proceures
-- 2021-03-18 , SivathanuM , Validated and fixed issues 
--**************************************************************************--
-- Create Assignment09DB 
Begin Try
	Use Master;
	If Exists(Select Name From SysDatabases Where Name = 'Assignment09DB_SivathanuM')
	 Begin 
	  Alter Database [Assignment09DB_SivathanuM] set Single_user With Rollback Immediate;
	  Drop Database Assignment09DB_SivathanuM;
	 End
	Create Database Assignment09DB_SivathanuM;
End Try
Begin Catch
	Print Error_Number();
End Catch
go
Use Assignment09DB_SivathanuM;

--Create table Students
Create Table Students
(StudentID [int] IDENTITY(1,1) NOT NULL 
,StudentNumber [nvarchar] (100) NOT NULL 
,StudentFirstName [nvarchar](100) NOT NULL
,StudentLastName [nvarchar](100) NOT NULL
,StudentEmail [nvarchar](100) NOT NULL
,StudentAddress1 [nvarchar](100)
,StudentAddress2 [nvarchar](100)
,StudentCity [nvarchar](100)
,StudentStateCode [int] 
,StudentZipCode [int] 
)
GO

-- Create Table Enrollments
Create Table Enrollments
(EnrollmentID [int] IDENTITY(1,1) NOT NULL 
,StudentID [int] NOT NULL
,CourseID [int] NOT NULL
,EnrollmentDate [date] NOT NULL
,EnrollmentPrice [money] NOT NULL
)
GO

-- Create Table Courses
Create Table Courses
(CourseID [int] IDENTITY(1,1) NOT NULL 
,CourseName [nvarchar](100) NOT NULL
,CourseStartDate [date] NOT NULL
,CourseEndDate [date] NOT NULL
,CourseDays [nvarchar] (100)
,CourseRooms [nvarchar](100)
,CourseStartTime [time]
,CourseEndTime [time]
,CourseCurrentPrice [money]
)
GO

-- Alter table students and add constraints
Begin  
	Alter Table Students 
	 Add Constraint pStudentID 
	  Primary Key (StudentID);	

    Alter Table Students 
	 Add Constraint ukStudentNumber 
	  Unique (StudentNumber);
      
    Alter Table Students 
	 Add Constraint ukStudentEmail 
	  Unique (StudentEmail);
END
go 

-- Alter table Courses and add constriants
Begin  
	Alter Table Courses 
	 Add Constraint pCourseID 
	  Primary Key (CourseID);

    Alter Table Courses 
	 Add Constraint CourseCurrentPrice 
	  Check (CourseCurrentPrice >= 0);

    Alter Table Courses 
	 Add Constraint ukCourseName 
	  Unique (CourseName);

End
go 

-- Alter table Enrollments and add constraints
Begin  
	Alter Table Enrollments 
	 Add Constraint pEnrollmentID 
	  Primary Key (EnrollmentID);

	Alter Table Enrollments
	 Add Constraint fkEnrollmentsToStudents
	  Foreign Key (StudentID) References Students(StudentID);

	Alter Table Enrollments
	 Add Constraint fkEnrollmentsToCourses
	  Foreign Key (CourseID) References Courses(CourseID);
End
go 

-- Create view for Students
Create View vStudents With SchemaBinding
 AS
  Select 
    StudentID
    ,StudentNumber
    ,StudentFirstName
    ,StudentLastName
    ,StudentEmail
    ,StudentAddress1
    ,StudentAddress2
    ,StudentCity
    ,StudentStateCode
    ,StudentZipCode 
        From dbo.Students;
go

--Create view for Enrollments
Create View vEnrollments With SchemaBinding
 AS
  Select 
    EnrollmentID
    ,StudentID
    ,CourseID
    ,EnrollmentDate
    ,EnrollmentPrice
        From dbo.Enrollments;
go

-- Create view for Courses
Create View vCourses With SchemaBinding
 AS
  Select 
    CourseID 
    ,CourseName
    ,CourseStartDate
    ,CourseEndDate
    ,CourseDays
    ,CourseRooms
    ,CourseStartTime
    ,CourseEndTime
    ,CourseCurrentPrice
        From dbo.Courses;
go

-- Create view for Students,Enrollments,Courses
Create or Alter View vStudentsByEnrollmentsByCourses
AS
  Select  
     CourseName
    ,CourseStartDate
    ,CourseEndDate
    ,CourseDays
    ,CourseRooms
    ,CourseStartTime
    ,CourseEndTime
    ,CourseCurrentPrice
    ,StudentFirstName
    ,StudentLastName
    ,StudentNumber
    ,StudentEmail
    ,StudentStateCode
    ,StudentAddress1
    ,StudentAddress2
    ,StudentCity
    ,StudentZipCode 
    ,EnrollmentDate
    ,EnrollmentPrice    
From vStudents
      Join vEnrollments
        On vStudents.StudentID=vEnrollments.StudentID
      Join vCourses
        On vCourses.CourseID=vEnrollments.CourseID
Go 

-- Create insert procedure for Students
Create or Alter Procedure pInsStudents 
	(@StudentNumber varchar(100)
    ,@StudentFirstName varchar(100)
    ,@StudentLastName varchar(100)
    ,@StudentEmail varchar(100)
    ,@StudentAddress1 varchar(100)
    ,@StudentAddress2 varchar(100)
    ,@StudentCity varchar(100)
    ,@StudentStateCode int
    ,@StudentZipCode int)
AS
 Begin
  Declare @RC int = 0;
  Begin Try
   Begin Transaction 
	Insert Into Students 
        (StudentNumber
        ,StudentFirstName
        ,StudentLastName
        ,StudentEmail
        ,StudentAddress1
        ,StudentAddress2
        ,StudentCity
        ,StudentStateCode
        ,StudentZipCode)
    Values(@StudentNumber
    ,@StudentFirstName
    ,@StudentLastName
    ,@StudentEmail
    ,@StudentAddress1
    ,@StudentAddress2
    ,@StudentCity
    ,@StudentStateCode
    ,@StudentZipCode );
   Commit Transaction
   Set @RC = +1
  End Try
  Begin Catch
   Rollback Transaction
   Print Error_Message()
   Set @RC = -1
  End Catch
  Return @RC;
 End
Go

-- Create update proceure for students
Create or Alter Procedure pUpdStudents 
	(@StudentID [int]
    ,@StudentNumber varchar(100)
    ,@StudentFirstName varchar(100)
    ,@StudentLastName varchar(100)
    ,@StudentEmail varchar(100)
    ,@StudentAddress1 varchar(100)
    ,@StudentAddress2 varchar(100)
    ,@StudentCity varchar(100)
    ,@StudentStateCode int
    ,@StudentZipCode int)
AS
 Begin
  Declare @RC int = 0;
  Begin Try
   Begin Transaction 
	Update Students Set
        StudentNumber=@StudentNumber
        ,StudentFirstName=@StudentFirstName
        ,StudentLastName=@StudentLastName
        ,StudentEmail=@StudentEmail
        ,StudentAddress1=@StudentAddress1
        ,StudentAddress2=@StudentAddress2
        ,StudentCity=@StudentCity
        ,StudentStateCode=@StudentStateCode
        ,StudentZipCode=@StudentZipCode
    Where StudentID=@StudentID;
    If(@@ROWCOUNT > 1) RaisError('Do not change more than one row!', 15,1);	
   Commit Transaction
   Set @RC = +1
  End Try
  Begin Catch
   Rollback Transaction
   Print Error_Message()
   Set @RC = -1
  End Catch
  Return @RC;
 End
Go

--Create delete procedure for students
Create or Alter Procedure pDelStudents
	(@StudentID int 
	)
 AS
 Begin
  Declare @RC int = 0;
  Begin Try
   Begin Transaction 
	Delete from Students where StudentID = @StudentID;
	If(@@ROWCOUNT > 1) RaisError('Do not Delete more than one row!', 15,1);	
   Commit Transaction
   Set @RC = +1
  End Try
  Begin Catch
   Rollback Transaction
   Print Error_Message()
   Set @RC = -1
  End Catch
  Return @RC;
 End
Go

-- Create Insert procedure for enrollments
Create or Alter Procedure pInsEnrollments 
	(@StudentID [int]
    ,@CourseID [int]
    ,@EnrollmentDate [date]
    ,@EnrollmentPrice[money])
AS
 Begin
  Declare @RC int = 0;
  Begin Try
   Begin Transaction 
	Insert Into Enrollments 
        (StudentID
        ,CourseID
        ,EnrollmentDate
        ,EnrollmentPrice)
    Values(@StudentID
    ,@CourseID
    ,@EnrollmentDate
    ,@EnrollmentPrice);
   Commit Transaction
   Set @RC = +1
  End Try
  Begin Catch
   Rollback Transaction
   Print Error_Message()
   Set @RC = -1
  End Catch
  Return @RC;
 End
Go

-- Create update procedure for enrollments
Create or Alter Procedure pUpdEnrollments 
	(@EnrollmentID int
    ,@StudentID int
    ,@CourseID int
    ,@EnrollmentDate date
    ,@EnrollmentPrice money)
AS
 Begin
  Declare @RC int = 0;
  Begin Try
   Begin Transaction 
	Update Enrollments set
        StudentID=@StudentID
        ,CourseID=@CourseID
        ,EnrollmentDate=@EnrollmentDate
        ,EnrollmentPrice=@EnrollmentPrice
    Where EnrollmentID=@EnrollmentID;
    If(@@ROWCOUNT > 1) RaisError('Do not change more than one row!', 15,1);	
   Commit Transaction
   Set @RC = +1
  End Try
  Begin Catch
   Rollback Transaction
   Print Error_Message()
   Set @RC = -1
  End Catch
  Return @RC;
 End
Go

-- Create delete procedure for enrollments
Create or Alter Procedure pDelEnrollments
	(@EnrollmentID int 
	)
 AS
 Begin
  Declare @RC int = 0;
  Begin Try
   Begin Transaction 
	Delete from Enrollments where EnrollmentID = @EnrollmentID;
	If(@@ROWCOUNT > 1) RaisError('Do not Delete more than one row!', 15,1);	
   Commit Transaction
   Set @RC = +1
  End Try
  Begin Catch
   Rollback Transaction
   Print Error_Message()
   Set @RC = -1
  End Catch
  Return @RC;
 End
Go

-- Create insert procedure for courses
Create or Alter Procedure pInsCourses 
	(@CourseName varchar(100)
    ,@CourseStartDate date
    ,@CourseEndDate date
    ,@CourseDays varchar(100)
    ,@CourseRooms varchar(100)
    ,@CourseStartTime time
    ,@CourseEndTime time
    ,@CourseCurrentPrice money)
AS
 Begin
  Declare @RC int = 0;
  Begin Try
   Begin Transaction 
	Insert Into Courses 
        (CourseName
        ,CourseStartDate
        ,CourseEndDate
        ,CourseDays
        ,CourseRooms
        ,CourseStartTime
        ,CourseEndTime
        ,CourseCurrentPrice)
    Values(@CourseName
    ,@CourseStartDate
    ,@CourseEndDate
    ,@CourseDays
    ,@CourseRooms
    ,@CourseStartTime
    ,@CourseEndTime
    ,@CourseCurrentPrice);
   Commit Transaction
   Set @RC = +1
  End Try
  Begin Catch
   Rollback Transaction
   Print Error_Message()
   Set @RC = -1
  End Catch
  Return @RC;
 End
Go

-- Create update procedure for courses
Create or Alter Procedure pUpdCourses 
	(@CourseID [int]
    ,@CourseName varchar(100)
    ,@CourseStartDate [date]
    ,@CourseEndDate [date]
    ,@CourseDays varchar(100)
    ,@CourseRooms varchar(100)
    ,@CourseStartTime [time]
    ,@CourseEndTime [time]
    ,@CourseCurrentPrice [money])
AS
 Begin
  Declare @RC int = 0;
  Begin Try
   Begin Transaction 
	Update Courses set
        CourseName=@CourseName
        ,CourseStartDate=CourseStartDate
        ,CourseEndDate=@CourseEndDate
        ,CourseDays=@CourseDays
        ,CourseRooms=@CourseRooms
        ,CourseStartTime=@CourseStartTime
        ,CourseEndTime=@CourseEndTime
        ,CourseCurrentPrice=@CourseCurrentPrice
    Where CourseID=@CourseID;
    If(@@ROWCOUNT > 1) RaisError('Do not change more than one row!', 15,1);	
   Commit Transaction
   Set @RC = +1
  End Try
  Begin Catch
   Rollback Transaction
   Print Error_Message()
   Set @RC = -1
  End Catch
  Return @RC;
 End
Go

-- Create delete procedure for courses
Create or Alter Procedure pDelCourses
	(@CourseID int 
	)
 AS
 Begin
  Declare @RC int = 0;
  Begin Try
   Begin Transaction 
	Delete from Courses where CourseID = @CourseID;
	If(@@ROWCOUNT > 1) RaisError('Do not Delete more than one row!', 15,1);	
   Commit Transaction
   Set @RC = +1
  End Try
  Begin Catch
   Rollback Transaction
   Print Error_Message()
   Set @RC = -1
  End Catch
  Return @RC;
 End
Go

-- Set Permissions 
Begin
--Set permissions for dbo.Courses
Deny Select , Insert , Update , Delete On [Dbo].[Courses] To Public;
Grant Select On [Dbo].[vCourses] To Public;
Grant Execute On [Dbo].[pInsCourses] To Public;
Grant Execute On [Dbo].[pUpdCourses] To Public;
Grant Execute On [Dbo].[pDelCourses] To Public;

-- Set permissions for dbo.Students
Deny Select , Insert , Update , Delete On [Dbo].[students] To Public;
Grant Select On [Dbo].[vStudents] To Public;
Grant Execute On [Dbo].[pInsStudents] To Public;
Grant Execute On [Dbo].[pUpdStudents] To Public;
Grant Execute On [Dbo].[pDelStudents] To Public;

-- Set permissions for dbo.Enrollments
Deny Select , Insert , Update , Delete On [Dbo].[Enrollments] To Public;
Grant Select On [Dbo].[vEnrollments] To Public;
Grant Execute On [Dbo].[pInsEnrollments] To Public;
Grant Execute On [Dbo].[pUpdEnrollments] To Public;
Grant Execute On [Dbo].[pDelEnrollments] To Public;
End
Go



-- Insert data into students table through insert procedure
Declare @Status int;
Exec @Status = pInsStudents 
    @StudentNumber='B-Smith-071'
    ,@StudentFirstName='Bob'
    ,@StudentLastName='Smith'
    ,@StudentEmail='Bsmith@HipMail.com'
    ,@StudentAddress1='123'
    ,@StudentAddress2='Main St'
    ,@StudentCity='Seattle WA'
    ,@StudentStateCode=1112222
    ,@StudentZipCode=98001
	;               
Select Case @Status
  When +1 Then 'Students Insert was successful!'
  When -1 Then 'Students Insert failed! Common Issues: Duplicate Data'
  End as [Status];
Go

-- Insert data into students table through insert procedure
Declare @Status int;
Exec @Status = pInsStudents 
    @StudentNumber='S-Jones-003'
    ,@StudentFirstName='Sue'
    ,@StudentLastName='Jones'
    ,@StudentEmail='SueJones@YaYou.com'
    ,@StudentAddress1='333'
    ,@StudentAddress2='1St Ave'
    ,@StudentCity='Seattle WA'
    ,@StudentStateCode=2314321
    ,@StudentZipCode=98001
	;               
Select Case @Status
  When +1 Then 'Students Insert was successful!'
  When -1 Then 'Students Insert failed! Common Issues: Duplicate Data'
  End as [Status];
Go

-- Insert data into Courses table through insert procedure
Declare @Status int;
Exec @Status = pInsCourses 
    @CourseName='SQL1 - Winter 2017'
    ,@CourseStartDate='2017-01-10'
    ,@CourseEndDate='2017-01-24'
    ,@CourseDays='10,17,24'
    ,@CourseRooms='A-201,B303'
    ,@CourseStartTime='6:00:00'
    ,@CourseEndTime='8:50:00'
    ,@CourseCurrentPrice=399
	;               
Select Case @Status
  When +1 Then 'Courses Insert was successful!'
  When -1 Then 'Courses Insert failed! Common Issues: Duplicate Data'
  End as [Status];
Go

-- Insert data into Courses table through insert procedure
Declare @Status int;
Exec @Status = pInsCourses 
    @CourseName='SQL2 - Winter 2017'
    ,@CourseStartDate='2017-01-31'
    ,@CourseEndDate='2017-02-14'
    ,@CourseDays='31,7,21'
    ,@CourseRooms='B303'
    ,@CourseStartTime='6:00:00'
    ,@CourseEndTime='8:50:00'
    ,@CourseCurrentPrice=399
	;               
Select Case @Status
  When +1 Then 'Courses Insert was successful!'
  When -1 Then 'Courses Insert failed! Common Issues: Duplicate Data'
  End as [Status];
Go

-- Insert data into Enrollments table through insert procedure
Declare @Status int;
Exec @Status = pInsEnrollments 
    @StudentID=1
    ,@CourseID=1
    ,@EnrollmentDate='2017-01-03'
    ,@EnrollmentPrice=399
	;               
Select Case @Status
  When +1 Then 'Enrollments Insert was successful!'
  When -1 Then 'Enrollments Insert failed! Common Issues: Duplicate Data'
  End as [Status];
Go

-- Insert data into Enrollments table through insert procedure
Declare @Status int;
Exec @Status = pInsEnrollments 
    @StudentID=2
    ,@CourseID=1
    ,@EnrollmentDate='2016-12-14'
    ,@EnrollmentPrice=349
	;               
Select Case @Status
  When +1 Then 'Enrollments Insert was successful!'
  When -1 Then 'Enrollments Insert failed! Common Issues: Duplicate Data'
  End as [Status];
Go

-- Insert data into Enrollments table through insert procedure
Declare @Status int;
Exec @Status = pInsEnrollments 
    @StudentID=2
    ,@CourseID=2
    ,@EnrollmentDate='2016-12-14'
    ,@EnrollmentPrice=349
	;               
Select Case @Status
  When +1 Then 'Enrollments Insert was successful!'
  When -1 Then 'Enrollments Insert failed! Common Issues: Duplicate Data'
  End as [Status];
Go

-- Insert data into Enrollments table through insert procedure
Declare @Status int;
Exec @Status = pInsEnrollments 
    @StudentID=1
    ,@CourseID=2
    ,@EnrollmentDate='2017-01-12'
    ,@EnrollmentPrice=399
	;               
Select Case @Status
  When +1 Then 'Enrollments Insert was successful!'
  When -1 Then 'Enrollments Insert failed! Common Issues: Duplicate Data'
  End as [Status];
Go


-- View contents of Students Courses and Enrollments through views created 
Select * From vStudents
Go
Select * from vCourses
Go
Select * from vEnrollments
Go
Select * from vStudentsByEnrollmentsByCourses